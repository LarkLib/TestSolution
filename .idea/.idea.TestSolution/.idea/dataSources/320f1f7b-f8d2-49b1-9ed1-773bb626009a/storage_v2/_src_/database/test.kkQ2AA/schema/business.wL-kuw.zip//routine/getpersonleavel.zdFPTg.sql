CREATE FUNCTION getpersonleavel(hiredate date)
  RETURNS character varying
LANGUAGE SQL
AS $$
SELECT CASE WHEN date_part('day', now() - hiredate::timestamp)<365*2 THEN 'new' ELSE 'old' END AS class --FROM business.persion;
$$;

