CREATE FUNCTION add(a integer, b numeric)
  RETURNS numeric
LANGUAGE SQL
AS $$
SELECT a+b;
$$;

